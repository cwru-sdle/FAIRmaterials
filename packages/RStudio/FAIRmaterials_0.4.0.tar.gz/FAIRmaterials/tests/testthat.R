library(testthat)
library(FAIRmaterials)

test_check("FAIRmaterials")
