## Test environments
* Ubuntu 21.04, R 4.1.1
* Windows through the devtools::check_win_devel()

## R CMD check results
There was a note about the cran-comments file, but the package book reccomends this file.

There was a note about a JsonFiles directory in the check. This is created as part of the package to store json files created as part of the FAIRify data function.

